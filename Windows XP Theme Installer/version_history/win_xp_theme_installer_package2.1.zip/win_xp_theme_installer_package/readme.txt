--------------------------
Windows XP Theme Installer
       Version 2.1
--------------------------

This version of the Windows XP Theme Installer was created with users like you in mind.

In order to do this properly, please follow these instructions laid out within this readme file.

To install the themes, you use the theme installer.

::WARNING - BEFORE YOU INSTALL THE THEMES, PLEASE READ THIS::
=============================================================
In previous releases, it was a requirement to keep this directory so you may uninstall properly. With the
new 2.1 release, all you need to do is run the uninstaller. Keep the .exe so you can uninstall everything
properly. If you decide to remove the direcroty, DO NOT RUN THE INSTALL FUNCTION! This is still a new program,
So please, please install with caution. This has been tested on my machine as well as others. This is a safe 
program, but follow my instructions, and you can install with no issue at all. If you decide to go against my
warning about running the installer if you remove the directory, follow the instructions in the fix.txt file.

::Installation Instructions::
=============================
1. Run Windows XP Theme Installer.exe
2. Follow directions as laid out in the program
3. Install using the install command
4. Restart your computer
5. Change the theme to Luna or Luna Aero
6. Right-Click the task bar, click Properties, then select the box to use small icons


::Uninstallation Instructions::
===============================
1. Change the Luna or Luna Aero theme back to the default theme
2. Right-Click the task bar, click Propertied, and uncheck the box that says "Use small icons"
3. Run Windows XP Theme Installer.exe
4. Uninstall by using the "uninstall" command
5. Restart your computer

::Version History::
===================
2.1 - AutoPatcher stores all files safely until uninstall is ran,
	then restores all files to normal
2.0 - New AutoPatcher included. No need for VistaGlazz
1.0-10 - Install based on your computer's architecture
1.0 - First release.

::Credits::
===========
Themes created by: Satokoro (You can find him on DeviantArt)
Original Luna theme (c) Microsoft
Patched DLL Files taken from VistaGlazz and tweeked some