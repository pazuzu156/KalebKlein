 --------------------------
 Windows XP Theme Installer
        Version 1.0
 --------------------------

This version of the Windows XP Theme Installer was created with users like you in mind.

In order to do this properly, please follow these instructions laid out within this readme file.

To install the themes, you use the theme installer. For the themes to take true effect, you need to install VistaGlazz

Download link: http://www.codegazer.com/vistaglazz/

::WARNING - BEFORE YOU INSTALL THE THEMES, PLEASE READ THIS::
=============================================================
If you install the theme, please keep this folder so you can uninstall the theme later if you wish
If you remove the folder, there is no guarantee that you can successfully uninstall the task bar properly.
This is still a new program, so please, please install with caution. This has been tested on my machine as well as others.
This is a safe program, but follow my instructions, and you can install with no issue at all.

::Installation Instructions::
=============================
1. Download VistaGlazz from the link above
2. Install VistaGlazz, patch your system, do not select "Reboot" (you can if you want though)
3. Run win_xp_theme_installer_1.0-20.exe and follow the instructions laid out in the installer
4. Restart your computer (installer gives you that option)

To uninstall the theme, simply run the installer with the "uninstall" keyword, restart is not needed in this unless you unpatch your computer with
VistaGlazz

::Version History::
===================
1.0 - First release.
1.0-10 - Install based on your computer's architecture

::Credits::
===========
Themes created by: Satokoro (You can find him on DeviantArt)
